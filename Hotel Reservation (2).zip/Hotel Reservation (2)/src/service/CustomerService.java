package service;

import model.Customer;

import java.util.*;

public class CustomerService {

    private static final Collection<Customer> customers = new ArrayList<>();
    private static final Map<String, Customer> customerInfo = new HashMap<String, Customer>();

    private static CustomerService customerService = null;
    private CustomerService(){}

    public static CustomerService getInstance()
    {
        if(null == customerService)
        {
            customerService = new CustomerService();
        }
        return customerService;
    }
    public void addCustomer(String email, String firstName, String lastName)
    {
        Customer newCustomer = new Customer(firstName, lastName, email);
        customers.add(newCustomer);
    }
    public static Customer getCustomer(String customerEmail){
        String cusEmail = customerEmail.toLowerCase(Locale.ROOT);
        for(Customer customer : customers){
            if(customer.getEmail().equals(customerEmail)){
                return customerInfo.get(cusEmail);
            }
        }
        return null;
    }
    private boolean findCustomer(String customerEmail){
        return customerInfo.containsKey(customerEmail);
    }

    public static Collection<Customer> getAllCustomers() {
        return customers;
    }
}
