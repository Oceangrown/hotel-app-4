package Menus;

import Resource.AdminResource;
import Resource.HotelResource;
import model.Customer;
import model.IRoom;
import model.Room;
import service.ReservationService;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;


public class AdminMenu {
    //public AdminMenu adminMenu = null;
    private static final List<IRoom> roomList = new ArrayList<>();
    private static final AdminResource adminResource = AdminResource.getInstance();
    private static final HotelResource hotelResource = HotelResource.getInstance();

    private AdminMenu(){}

    static void launchAdminMenu(){
        boolean keepRunning = true;
        String optionAdminMenu;

        while(keepRunning){
            try{
                Scanner adminMenuScan = new Scanner(System.in);
                System.out.println("--------------------------");
                System.out.println("1. See all Customers");
                System.out.println("2. See all Rooms");
                System.out.println("3. See all Reservations");
                System.out.println("4. Add a Room");
                System.out.println("5. Back to Main Menu");
                System.out.println("Select a Menu option");
                System.out.println("---------------------------");
                optionAdminMenu = adminMenuScan.nextLine();
                switch(optionAdminMenu){
                    case "1" ->{
                        Collection<Customer> allCustomers = adminResource.getAllCustomers();
                        if(allCustomers.isEmpty()){
                            System.out.println("No customer found");
                        } else{
                            for (Customer customer : allCustomers){
                                System.out.println(customer.toString());
                            }
                        }
                    }
                    case "2" -> {
                        Collection<IRoom> roomCollection = adminResource.getAllRooms();
                        if (roomCollection.isEmpty()) {
                            System.out.println("No room found");
                        } else{
                            for (IRoom room : roomCollection){
                                System.out.println(room.toString());
                            }
                        }
                    }
                    case "3" -> adminResource.displayAllReservations();
                    case "4" -> adminResource.addRoom(addANewRoom());
                    case "5" -> keepRunning = false;
                    default -> System.out.println("Select an option 1-5");

                }

            } catch (Exception ex){
                System.out.println("Error, invalid format");
            }
        }
    }

    private static List<IRoom> addANewRoom(){
        boolean keepRunning = true;
        String yesNo;
        String yesNoRegex = "[yesYnoN]";
        Pattern pattern = Pattern.compile(yesNoRegex);
        roomList.clear();
        IRoom room = null;
        assert false;
        room = new Room(room.getRoomNumber(), room.getRoomPrice(), room.getRoomType());
        roomList.add(room);
        while(keepRunning){
            try{
                Scanner yesNoScan = new Scanner(System.in);
                System.out.println("Add a room?");
                yesNo = yesNoScan.nextLine();

                if(!pattern.matcher(yesNo).matches()){
                    System.out.println();
                    throw new IllegalArgumentException();
                } else if(yesNo.equals("yes")){
                room = (IRoom) ReservationService.findRooms();

            }
                else if(yesNo.equals("no")){
                    keepRunning = false;
                }

        } catch(Exception ex){
                System.out.println("Input yes or no");
            }

    }
        return roomList;
}
}
