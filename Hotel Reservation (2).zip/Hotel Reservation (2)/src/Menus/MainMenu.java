package Menus;

import Resource.AdminResource;
import Resource.HotelResource;
import model.Customer;
import model.IRoom;
import model.Reservation;
import service.ReservationService;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Scanner;
import java.util.regex.Pattern;



public class MainMenu {
    public static AdminResource adminResource = AdminResource.getInstance();
    public static HotelResource hotelResource = HotelResource.getInstance();
    private static Collection<Reservation> reservationCollection = new HashSet<>();
    private static Collection<IRoom> availableRooms = new HashSet<>();

    private MainMenu(){

    }
    public static void launchMainMenu(){
        boolean keepRunning = true;
        String optionMainMenu;
        try (Scanner mainMenuScan = new Scanner(System.in)){
            while(keepRunning){
                try{
                    System.out.println("Welcome to the main menu");
                    System.out.println("1. Find and reserve a room");
                    System.out.println("2. See my reservations");
                    System.out.println("3. Create an account");
                    System.out.println("4. Admin");
                    System.out.println("5. Exit");
                    System.out.println("Please select an option 1-5");
                    optionMainMenu = mainMenuScan.next();


                    switch(optionMainMenu){
                        case "1" -> {
                            String yesNo;
                            String yesNoRegex = "[yes no Yes No]";
                            Pattern pattern = Pattern.compile(yesNoRegex);


                            availableRooms = ReservationService.findRooms();
                            if (availableRooms.isEmpty()){
                                System.out.println("There are no rooms available those days");
                                return;
                            }
                            for(IRoom room : availableRooms){
                                System.out.println(room.toString());
                            }
                            Scanner yesNoScan = new Scanner(System.in);
                            while(keepRunning){
                                try{
                                    System.out.println("Do you want to book a room? yes/no");
                                    yesNo = yesNoScan.nextLine();
                                    if (yesNo.equals("yes")){
                                        reserveNewRoom();
                                        return;
                                    }
                                    if(yesNo.equals("no")){
                                        return;
                                    }
                                    else{
                                        throw new IllegalArgumentException("Invalid format, enter yes or no");
                                    }
                                } catch(Exception ex){
                                    System.out.println("Not a valid input");
                                }
                            }
                        }
                        case "2" -> {
                            reservationCollection.clear();
                            String customersEmail = getEmail();
                            reservationCollection = hotelResource.getCustomerReservations(customersEmail);
                            if(reservationCollection.isEmpty()){
                                System.out.println("No reservations under this email");
                            }
                            else
                            {
                                for(Reservation currentReservation : reservationCollection){
                                    currentReservation.toString();
                                }
                            }
                        }
                        case "3" -> {
                            String email = getEmail();
                            String firstName = getFirstName("First Name");
                            String lastName = getLastName("Last Name");
                            hotelResource.createACustomer(email, firstName, lastName);
                        }
                        case "4" -> AdminMenu.launchAdminMenu();
                        case "5" -> keepRunning = false;
                        default -> System.out.println("Select option 1-5");


                    }
                }catch (Exception ex){
                    System.out.println(ex.toString());
                }
            }
        }
    }
    public static String getMainMenuOption(){
        String switchOption;
        Scanner mainMenuScanner = new Scanner(System.in);
        switchOption = mainMenuScanner.nextLine();
        return switchOption;
    }
    public static void reserveNewRoom() {
        String yesNo;
        String email = null;
        String roomNumber = null;
        IRoom room = null;
        boolean keepRunning = true;
        String yesNoRegex = "[yes no Yes No ]";
        Pattern pattern = Pattern.compile(yesNoRegex);
        while (keepRunning) {
            try {
                Scanner yesNoScan = new Scanner(System.in);
                System.out.println("Do you have an existing account? yes/no");
                yesNo = yesNoScan.nextLine();

                if (!pattern.matcher(yesNo).matches()) {
                    throw new IllegalArgumentException();
                } else if (yesNo.equals("yes")) {
                    email = getEmail();
                    Customer customer = hotelResource.getCustomer(email);
                    room = hotelResource.getRoom(roomNumber);
                    Date checkInDate = getDate("checkInDate");
                    Date checkOutDate = getDate("checkOutDate");
                    hotelResource.bookARoom(email, room, checkInDate, checkOutDate);
                    keepRunning = false;

                } else if (yesNo.equals("no")) {
                    keepRunning = false;
                }
            } catch(Exception ex){
                System.out.println("No Account Found");
            }
        }
    }
    public static Date getDate(String dateType){
        Date stayDate = null;
        boolean keepRunning = true;
        DateFormat dateFormat = new SimpleDateFormat("mm/dd/yyyy");
        String date;
        while(keepRunning){
            System.out.println("Enter" + dateType + "date mm/dd/yyyy example 06/14/2022");
            try{
                Scanner scanDate = new Scanner(System.in);
                date = scanDate.nextLine();
                stayDate = dateFormat.parse(date);
            } catch(Exception ex){
                System.out.println("Not a valid Date");
                continue;
            }
            keepRunning = false;
        }
        return stayDate;
    }
    public static String getEmail() {
        String email = null;
        String emailRegex = "^(.+)@(.+).(.+)$";
        Pattern pattern = Pattern.compile(emailRegex);
        boolean keepRunning = true;

        while (keepRunning) {
            try {
                Scanner emailScan = new Scanner(System.in);
                System.out.println("Enter Email");
                email = emailScan.nextLine();
                if(!pattern.matcher(email).matches()){
                    throw new IllegalArgumentException();
                } else {
                    keepRunning = false;
                }
            } catch (Exception ex) {
                System.out.println("Invalid Email");
            }
        }
        return email;
    }

    public static String getFirstName(String first_name){
        String firstName = null;
        String nameRegex = "[A-Z]+(['-]*[a-zA-Z]+)*";
        Pattern pattern = Pattern.compile(nameRegex);
        boolean keepRunning = true;
        while(keepRunning){
            try{
                Scanner nameScan = new Scanner(System.in);
                System.out.println("firstName");
                firstName = nameScan.nextLine();
                if(!pattern.matcher(firstName).matches()){
                    throw new IllegalArgumentException();
                }
                else{
                    keepRunning = false;

                }
            }catch(Exception ex){
                System.out.println("No first name found");
            }
        }
        return firstName;
    }
    public static String getLastName(String last_name){
        String lastName = null;
        String nameRegex = "[A-Z]+(['-]*[a-zA-Z]+)*";
        Pattern pattern = Pattern.compile(nameRegex);
        boolean keepRunning = true;
        while(keepRunning){
            try{
                Scanner nameScan = new Scanner(System.in);
                System.out.println("lastName");
                lastName = nameScan.nextLine();
                if(!pattern.matcher(lastName).matches()){
                    throw new IllegalArgumentException();
                }
                else{
                    keepRunning = false;

                }
            }catch(Exception ex){
                System.out.println("No first name found");
            }
        }

        return lastName;
    }



}
